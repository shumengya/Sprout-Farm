#!/bin/bash
# 设置UTF-8字符编码
export LANG=en_US.UTF-8
# 执行Python服务器程序
python3 TCPGameServer.py